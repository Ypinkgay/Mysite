# Projeto IA - Render

Este projeto contém:

- `/backend`: API REST com Node.js, Express e MongoDB Atlas
- `/site`: Site estático em HTML e JavaScript

## 🚀 Como publicar no Render

### Backend (Node.js)
1. Vá para https://render.com
2. Crie um novo projeto como **Web Service**
3. Escolha a pasta `backend`
4. Configure:
   - **Build Command:** `npm install`
   - **Start Command:** `node index.js`
   - **Environment Variables:**
     - `MONGO_URI` = sua string do MongoDB Atlas
     - `JWT_SECRET` = sua chave secreta

### Frontend (HTML)
1. Crie um novo projeto como **Static Site**
2. Escolha a pasta `site`
3. Configure:
   - **Build Command:** `echo ok`
   - **Publish Directory:** `.`

⚠️ Lembre-se de atualizar a constante `API_URL` no HTML para apontar para a URL real do seu backend Render.
